# Dashboard
This is a student dashboard for the college of Vivekanda institute of proffesional studies made for as a project for our summer internship in our Institute.
